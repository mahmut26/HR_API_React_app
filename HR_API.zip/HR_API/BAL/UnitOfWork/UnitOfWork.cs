﻿using DAL.Database.Company;
using DAL.Database.DatabaseContext;
using DAL.Database.DatabaseIdentity;
using DAL.Database.DatabaseModels;
using DAL.Database.RequestCompany;
using DAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly Database_Context _context;

        public IGenericRepository<User> users { get; private set; }
        public IGenericRepository<UserInfo> userInfo { get; private set; }

        public IGenericRepository<Expense> expenses { get; private set; }

        public IGenericRepository<Leave> leaves { get; private set; }

        public IGenericRepository<CompanyData> companyData { get; private set; }

        public IGenericRepository<Education> education { get; private set; }

        public IGenericRepository<Experience> experience { get; private set; }

        public IGenericRepository<NewCompanyRequest> reqComp { get; private set; }

        public IGenericRepository<Photo> photoS { get; private set; }

        public UnitOfWork(Database_Context context)
        {
            _context = context;

            users = new GenericRepository<User>(context);

            userInfo = new GenericRepository<UserInfo>(context);

            expenses = new GenericRepository<Expense>(context);

            leaves = new GenericRepository<Leave>(context);

            companyData = new GenericRepository<CompanyData>(context);

            education = new GenericRepository<Education>(context);

            experience = new GenericRepository<Experience>(context);

            reqComp = new GenericRepository<NewCompanyRequest>(context);

            photoS = new GenericRepository<Photo>(context);
        }

        public async Task SaveAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}
