﻿using DAL.Database.Company;
using DAL.Database.DatabaseIdentity;
using DAL.Database.DatabaseModels;
using DAL.Database.RequestCompany;
using DAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.UnitOfWork
{
    public interface IUnitOfWork
    {
        IGenericRepository<User> users { get; }
        IGenericRepository<UserInfo> userInfo { get; }
        IGenericRepository<Expense> expenses { get; }
        IGenericRepository<Leave> leaves { get; }
        IGenericRepository<CompanyData> companyData { get; }
        IGenericRepository<Education> education { get; }
        IGenericRepository<Experience> experience { get; }
        IGenericRepository<NewCompanyRequest> reqComp { get; }
        IGenericRepository<Photo> photoS { get; }
        Task SaveAsync();
    }
}
