﻿using DAL.Database.Company;
using DAL.Database.DatabaseIdentity;
using DAL.Database.DatabaseModels;
using DAL.Database.RequestCompany;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Database.DatabaseContext
{
    public class Database_Context : IdentityDbContext<User, Role, string>
    {
        public Database_Context(DbContextOptions<Database_Context> options) : base(options)
        {
        }
        public DbSet<User> Users { get; set; }
        public DbSet<UserInfo> UserInfos { get; set; }
        public DbSet<Expense> Expenses { get; set; }
        public DbSet<Leave> Leaves { get; set; }
        public DbSet<Experience> Experiences { get; set; }
        public DbSet<Education> Educations { get; set; }
        public DbSet<NewCompanyRequest> NewCompanyReqs { get; set; }
        public DbSet<CompanyData> CompanyDatas { get; set; }
        public DbSet<Photo> Photos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>()
                .HasOne(k => k.userInfo)
                .WithOne(ko => ko.user)
                .HasForeignKey<UserInfo>(ko => ko.userId);

            modelBuilder.Entity<User>()
                .HasOne(k => k.photo)
                .WithOne(p=>p.user)
                .HasForeignKey<Photo>(p=>p.userId);
        }
    }
}

