﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DTOs.LoginDTO
{
    public class DTOLOG
    {
        public string a { get; set; }

        public string b { get; set; }
    }

}
