﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DTOs.SADTO
{
    public class RegisDTO
    {
        public string mail { get; set; }
        public string passwd { get; set; }
        public string companyName { get; set; }
    }
}
