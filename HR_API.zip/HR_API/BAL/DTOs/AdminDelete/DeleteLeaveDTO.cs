﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DTOs.AdminDelete
{
    public class DeleteLeaveDTO
    {
        public string mail {  get; set; }
        public int leaveid { get; set; }
    }
}
