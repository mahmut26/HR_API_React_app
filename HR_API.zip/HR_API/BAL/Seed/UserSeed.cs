﻿using DAL.Database.DatabaseIdentity;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Seed
{
    public class UserSeed
    {
        private readonly UserManager<User> _userManager;
        public UserSeed(UserManager<User> userManager)
        {
            _userManager = userManager;
        }
        public async Task SeedUsersAsync()
        {
            var users = new List<User>
            {
                new User { UserName = "admin@admin.com", Email = "admin@admin.com",CompanyName = "ProgramCompany" }
            };

            foreach (var user in users)
            {
                if (await _userManager.FindByEmailAsync(user.Email) == null)
                {
                    var result = await _userManager.CreateAsync(user, "Admin123!"); 
                    if (result.Succeeded)
                    {
                        await _userManager.AddToRoleAsync(user, "SuperAdmin");
                    }
                }
            }
        }
    }
}

