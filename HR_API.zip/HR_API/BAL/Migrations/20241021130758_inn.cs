﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DAL.Migrations
{
    /// <inheritdoc />
    public partial class inn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Photos_UserInfos_userinfoId",
                table: "Photos");

            migrationBuilder.DropIndex(
                name: "IX_Photos_userinfoId",
                table: "Photos");

            migrationBuilder.DropColumn(
                name: "userinfoId",
                table: "Photos");

            migrationBuilder.AddColumn<string>(
                name: "userId",
                table: "Photos",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_Photos_userId",
                table: "Photos",
                column: "userId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Photos_AspNetUsers_userId",
                table: "Photos",
                column: "userId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Photos_AspNetUsers_userId",
                table: "Photos");

            migrationBuilder.DropIndex(
                name: "IX_Photos_userId",
                table: "Photos");

            migrationBuilder.DropColumn(
                name: "userId",
                table: "Photos");

            migrationBuilder.AddColumn<int>(
                name: "userinfoId",
                table: "Photos",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Photos_userinfoId",
                table: "Photos",
                column: "userinfoId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Photos_UserInfos_userinfoId",
                table: "Photos",
                column: "userinfoId",
                principalTable: "UserInfos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
